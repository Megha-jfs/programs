package com.mobile.oops;

import java.util.ArrayList;

public class App 
{
	public static void main(String args[])
	{
	Mobile mob=new Mobile();
	mob.setDetails();
	mob.displayDetails();
	
	Mobile mob1=new Mobile("samsung m40",20000,"15-May-2018","7 inch",1,"Andriod 9");
	System.out.println("**************************************");
	System.out.println(mob1);
	
	Mobile m[]=new Mobile[2];
	m[0]=new Mobile("mi a1",15000,"22-aug-2016","6 inch",1,"Android 6");
	m[1]=new Mobile("mi a2",12000,"12-june-2016","5 inch",1,"Android 7");
	for(int i=0;i<m.length;i++)
		System.out.println(m[i]);
	
	Mobile m1=new Mobile("oppo 1",15000,"22-aug-2016","6 inch",1,"Android 6");
	Mobile m2=new Mobile("vivo 1",15000,"22-aug-2016","6 inch",1,"Android 6");
	ArrayList arr=new ArrayList();
	arr.add(m1);
	arr.add(m2);
	arr.add(null);
	System.out.println(arr);
	
	}
}

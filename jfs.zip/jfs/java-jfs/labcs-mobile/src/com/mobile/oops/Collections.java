package com.mobile.oops;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;
import java.util.Iterator;


//import javax.swing.text.html.HTMLDocument.Iterator;

import java.util.HashMap;

public class Collections 
{
	public static void main(String args[])
	{
		arraylistExample();
		//mapimp();
	}

	public static void arraylistExample() {
		List<String> arraylist = new ArrayList<String>();
		arraylist.add("Abc");
		arraylist.add("Def");
		arraylist.add("Pqr");
		arraylist.add("Xyz");
		//arraylist.remove(1);
		System.out.println(arraylist);
	}
	public static void mapimp(){
	Map<Integer,String> map=new HashMap<Integer,String>();
	map.put(1,"abc");
	map.put(2,null);
	map.put(3,null);
	map.put(null,"pqr");
	map.put(null,"xyz");
	System.out.println(map);
	Set keys =  map.keySet();
	Iterator iterator = keys.iterator();
	
	while(iterator.hasNext())
	{
	  Object key   = iterator.next();
	  Object value = map.get(key);
	  System.out.println(value);
	}
	
}
}
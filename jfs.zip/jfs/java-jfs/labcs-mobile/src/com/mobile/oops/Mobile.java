package com.mobile.oops;

public class Mobile 
{
	String name;
	double price;
	String date_of_release;
	String screen_size;
	double weight;
	String os_name;
	float f=1;
	Mobile()
	{
	
	}
	Mobile(String name,double price,String date_of_release,String screen_size,double weight,String os_name) 
	{
		this.name=name;
		this.price=price;
		this.date_of_release=date_of_release;
		this.screen_size=screen_size;
		this.weight=weight;
		this.os_name=os_name;
	}
	void setDetails() 
	{
		name="honor 9 lite";
		price=11000;
		date_of_release="11-Dec-2017";
		screen_size="6 inch";
		weight=1;
		os_name="Android 7";
				
	}
	void displayDetails()
	{
		System.out.println("Mobile Name     : "+name);
		System.out.println("Price           : "+price);
		System.out.println("Date of release : "+date_of_release);
		System.out.println("Screen size     : "+screen_size);
		System.out.println("Weight          : "+weight+"kg");
		System.out.println("Operating Sytem : "+os_name);
	}
	@Override
	public String toString() {
		return "Mobile [name=" + name + ", price=" + price + ", date_of_release=" + date_of_release + ", screen_size="
				+ screen_size + ", weight=" + weight + ", os_name=" + os_name + "]";
	}
	
}

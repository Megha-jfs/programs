package com.project.oops;

import java.util.HashMap;
import java.util.Map;

public class FoodArrayList 
{
	public void createFoodList()
	{
		Map<Integer,String> foodList=new HashMap<Integer,String>();
		foodList.put(1,"Orange");
		foodList.put(2,"Apple");
		foodList.put(3,"Mango");
		foodList.put(4,"Guava");
		foodList.put(5,"Pomegranate");
		System.out.println(foodList);
	}
}

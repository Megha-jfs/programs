package com.project.oops;

public class Book extends Shop
{
	
	@Override
	public void productId() 
	{
		System.out.println("Book product id is 3");
	}
}

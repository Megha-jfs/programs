package com.project.oops;
import java.util.Map;
import java.util.HashMap;
public class Food extends Shop
{
	int foodId;
	String foodName;
	float foodPrice;
	Food()
	{
		
	}
	Food(int foodId,String foodName,float foodPrice)
	{
		this.foodId=foodId;
		this.foodName=foodName;
		this.foodPrice=foodPrice;
	}
	@Override
	public void productId() 
	{
		System.out.println("Food product id is 2");
	}
	
	
}

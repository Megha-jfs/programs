package com.project.oops;

public class Electronics extends Shop
{
	
	@Override
	public void productId() 
	{
		System.out.println("Electronics product id is 1");
	}
	
}

package com.project.oops;
import java.util.Scanner;
public class OnlineShoping 
{
	public static void main(String args[])
	{
		
		System.out.println("WELCOME to online shopping with us.");
		System.out.println("What do you want to do?\nSelect : \n1. Shop\n2. View cart\n3. Payment ");
		Scanner sc=new Scanner(System.in);
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1: 
			System.out.println("WELCOME to shopping!\nSelect : \n1. Electronics\n2. Food\n3. Books\n4. Clothes");
			int shopChoice=sc.nextInt();
			switch(shopChoice)
			{
			case 1: 
				Electronics electronics=new Electronics();
				electronics.productId();
				break;
			case 2:
				Food food=new Food();
				
				food.productId();
				
				break;
			case 3:
				Book book=new Book();
				book.productId();
				break;
			case 4:
				Clothes clothes=new Clothes();
				clothes.productId();
				break;
			default: 
				System.out.println("Oops! Wrong Choice.");
			}
			break;
		case 2:
			System.out.println("Select : \n1.");
			break;
		case 3:
			System.out.println("Select : \n1.");
			break;
		default: 
			System.out.println();
			
			
		}
		
	}
}

package com.project.oops;

public class Clothes extends Shop
{
	
	@Override
	public void productId() 
	{
		System.out.println("Clothes product id is 4");
	}
	
}

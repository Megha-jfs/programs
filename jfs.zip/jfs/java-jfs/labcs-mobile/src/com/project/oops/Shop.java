package com.project.oops;
import java.util.Scanner;

public abstract class Shop 
{
	//boolean availability;
	public abstract void productId();
	
}

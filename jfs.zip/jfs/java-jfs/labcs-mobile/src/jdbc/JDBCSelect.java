package jdbc;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JDBCSelect 
{
	public static void main(String[] args) 
	{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("success");
			Connection connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","hr");
			System.out.println("connection successful");
			Statement statement=connection.createStatement();
			ResultSet resultset=statement.executeQuery("select * from employees");
//			while(resultset.next())
//			{
//				int employeeId=resultset.getInt("employee_id");
//				String firstName=resultset.getString("first_name");
//				System.out.println(employeeId +""+firstName);
//			}
			//System.out.println(resultset);
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		} catch (SQLException e) {
			System.out.println(e);
	}
}
}

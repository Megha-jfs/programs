package com.postassesment;

public class CustomerException extends RuntimeException 
{
	
}

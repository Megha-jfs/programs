package com.project;
//POJO-PLAIN OLD JAVA OBJECT
public class Customer 
{
	String Customer_Id;
	String Password;
	Customer()
	{
		
	}
	public String getCustomer_Id() {
		return Customer_Id;
	}
	public void setCustomer_Id(String customer_Id) {
		Customer_Id = customer_Id;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	
}

package com.aerospace;

public class AerospaceException extends RuntimeException 
{
	
}

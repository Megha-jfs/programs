package com.aerospace;

public abstract class Aircraft 
{
	public abstract void fly();
	public abstract void addFuel();
	
}

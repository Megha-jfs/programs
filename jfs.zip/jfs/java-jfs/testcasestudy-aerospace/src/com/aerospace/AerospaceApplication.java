package com.aerospace;

import java.util.List;
import java.util.ArrayList;

public class AerospaceApplication 
{
	static List aeroplanelist=new ArrayList();
	
	public static void main(String[] args) 
	{
		Aeroplane aeroplane[]=new Aeroplane[3];
		aeroplane[0]=new Aeroplane(1,"Air Asia");
		aeroplane[1]=new Aeroplane(2,"Indigo");
		aeroplane[2]=new Aeroplane(3,"Air India");
		for(int i=0;i<3;i++)
		{	
			addAeroplane(aeroplane[i]);
		}
		System.out.println(aeroplanelist);
	}
	public static void addAeroplane(Aeroplane aeroplane)
	{
		try
		{
			aeroplanelist.add(aeroplane);
			//System.out.println(aeroplanelist);
			System.out.println("Aeroplane added successfully");
		}
		catch(AerospaceException e)
		{
			System.out.println("Failed!");
		}
	}
	//public static void deleteAeroplane(Aeroplane aeroplane)
}

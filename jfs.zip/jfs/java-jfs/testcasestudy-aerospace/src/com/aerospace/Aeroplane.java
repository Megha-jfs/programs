package com.aerospace;

public class Aeroplane extends Aircraft 
{
	public int aeroplaneId;
	public String aeroplaneName;
	public Aeroplane()
	{
		
	}
	public Aeroplane(int aeroplaneId,String aeroplaneName) 
	{
		this.aeroplaneId=aeroplaneId;
		this.aeroplaneName=aeroplaneName;
	}
	@Override
	public void fly() 
	{
		System.out.println("Flying horizontally");
	}

	@Override
	public void addFuel() 
	{
	System.out.println("Fuel tank in wings");
	}
	@Override
	public String toString() {
		return "Aeroplane \n[aeroplaneId=" + aeroplaneId + "\naeroplaneName=" + aeroplaneName + "]";
	}
	
}
